#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "list.h"
#include "hash.h"
#include "bitmap.h"

typedef struct list_{ //각 list의 맨 앞에서 list의 이름으로 list를 구분해줌
    char name[15];
    struct list *link;
}list_n;
list_n L[10];

struct hash_item
{
	struct hash_elem elem;
	int data;
};

typedef struct hash_{
    char name[15];
    struct hash *link;
}hash_n;
hash_n H[10];

typedef struct bitmap_{
    char name[15];
    struct bitmap *link;
}bitmap_n;
bitmap_n B[10];

int search_l_idx(int cnt_l, char *name){
    int i;
    for (i=0;i<cnt_l;i++){
        if (!strcmp(name, L[i].name))
            break;
    }
    return i;
}

int search_h_idx(int cnt_l, char *name){
    int i;
    for (i=0;i<cnt_l;i++){
        if (!strcmp(name, H[i].name))
            break;
    }
    return i;
}

int search_b_idx(int cnt_l, char *name){
    int i;
    for (i=0;i<cnt_l;i++){
        if (!strcmp(name, B[i].name))
            break;
    }
    return i;
}

/*list function*/
bool list_less(const struct list_elem *a, const struct list_elem *b, void *aux){
    struct list_item *ai,*bi;
    ai = list_entry(a, struct list_item, elem);
    bi = list_entry(b, struct list_item, elem);

    if (ai->data < bi->data)
        return true;
    else
        return false;
}

/*hash functions*/
bool hash_less(const struct hash_elem *a, const struct hash_elem *b, void *aux){
    struct hash_item *ai,*bi;
    ai = hash_entry(a, struct hash_item, elem);
    bi = hash_entry(b, struct hash_item, elem);

    if (ai->data < bi->data)
        return true;
    else
        return false;
}

unsigned hash_hash (const struct hash_elem *e, void *aux){
    struct hash_item *h = hash_entry(e,struct hash_item,elem);
    return hash_int(h->data);
}

/*hash actions functions*/
void hash_action_square(struct hash_elem *e, void *aux){
    struct hash_item *h = hash_entry(e,struct hash_item,elem);
    h->data *= h->data;
}

void hash_action_triple(struct hash_elem *e, void *aux){
    struct hash_item *h = hash_entry(e,struct hash_item,elem);
    h->data = (h->data)*(h->data)*(h->data);
}

void hash_action_destructor(struct hash_elem *e, void *aux){
    struct hash_item *h = hash_entry(e,struct hash_item,elem);
    free(h);
}

///
int main(){
    char command[100],t_cmd[50],cmd1[20],cmd2[20],cmd3[20],cmd4[20],cmd5[20];
    int cnt_l = 0,cnt_h = 0, index_l,index_h, count;
    size_t  cnt_b = 0, index_b;
    //struct list_item *new_item=(struct list_item*)malloc(sizeof(struct list_item)); /////
    //struct list_item *temp=(struct list_item*)malloc(sizeof(struct list_item)); ////
    //struct hash_elem *el = (struct hash_elem*)malloc(sizeof(struct hash_elem)); ////
    //struct hash_item *ite = (struct hash_item*)malloc(sizeof(struct hash_item)); ////

    while(1){
        fgets(command,sizeof(command),stdin);
        command[strlen(command)-1] = '\0';
        strcpy(t_cmd,strtok(command," "));

        if (!strcmp(t_cmd,"create")){
            strcpy(cmd1,strtok(NULL," "));
            if (!strncmp(cmd1,"list",4)){
                L[cnt_l].link=(struct list*)malloc(sizeof(struct list));
                list_init(L[cnt_l].link);
                strcpy(L[cnt_l].name,strtok(NULL," "));
                cnt_l++;
            }
            else if (!strncmp(cmd1,"hashtable",9)){
                void *aux;
                H[cnt_h].link=(struct hash*)malloc(sizeof(struct hash));
                hash_init(H[cnt_h].link, hash_hash, hash_less, aux);
                strcpy(H[cnt_h].name,strtok(NULL," "));
                cnt_h++;
            }
            else if (!strncmp(cmd1,"bitmap",6)){
                size_t bit_cnt;
                strcpy(cmd2, strtok(NULL," "));
                strcpy(cmd3, strtok(NULL," "));
                strcpy(B[cnt_b].name,cmd2);

                bit_cnt = atoi(cmd3);
                B[cnt_b].link = bitmap_create(bit_cnt);
                cnt_b++;
            }
        }
        else if (!strcmp(t_cmd,"dumpdata")){
            struct list_elem *e;
            struct list_item *idxitem;
            strcpy(cmd1,strtok(NULL," "));
            count = 0;

            if (!strncmp(cmd1,"list",4)){
                index_l = search_l_idx(cnt_l,cmd1);
                for (e = list_begin(L[index_l].link);e!=list_end(L[index_l].link);e=list_next(e)){
                    idxitem = list_entry(e,struct list_item,elem);
                    printf("%d ",idxitem->data);
                    count++;
                }
                if (count)
                    printf("\n");
            }
            else if (!strncmp(cmd1,"hash",4)){ ///////////////////////
                index_h = search_h_idx(cnt_h,cmd1);
                for(int i=0; i<H[index_h].link->bucket_cnt; i++){
					for(e = list_begin(&(H[index_h].link->buckets[i])); e!=list_end(&(H[index_h].link->buckets[i])); e=list_next(e)){

						struct hash_elem *l = list_entry(e, struct hash_elem, list_elem);
						struct hash_item *t = hash_entry(l, struct hash_item, elem);
						printf("%d ",t->data);
                        count++;
					}
				}
                if (count)
				    printf("\n");
            }
            else if (!strncmp(cmd1,"bm",2)){
                index_b = search_b_idx(cnt_b,cmd1);
                for (int i=0;i<bitmap_size(B[index_b].link);i++){
                    if (bitmap_test(B[index_b].link,i)==0)
                        printf("0");
                    else
                        printf("1");
                }
                printf("\n");
            }
        }
        else if (!strcmp(t_cmd,"delete")){
            strcpy(cmd1,strtok(NULL," "));
            for (int i=0;i<10;i++){
                if (!strcmp(cmd1,L[i].name)){
                    for (int j=i;j<cnt_l;j++)
                        L[j] = L[j+1];
                    cnt_l--;
                    break;
                }
                else if (!strcmp(cmd1,H[i].name)){
                    hash_destroy(H[i].link,hash_action_destructor);
                    cnt_h--;
                    break;
                }
                else if (!strcmp(cmd1,B[i].name)){
                    bitmap_destroy(B[i].link);
                    cnt_b--;
                    break;
                }
            }
        }
        else if (!strcmp(t_cmd,"quit")){
            break;
        }

        ///list 명령어
        else if (!strcmp(t_cmd,"list_insert")){
            struct list_elem *before;
            struct list_item *new_item=(struct list_item*)malloc(sizeof(struct list_item));
            
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            before = list_begin(L[index_l].link);

            for (int i=0;i<atoi(cmd2);i++)
                before = list_next(before);
            list_insert(before,&(new_item->elem));
            new_item = list_entry(&(new_item->elem),struct list_item,elem);
            new_item->data = atoi(cmd3);
        }
        else if (!strcmp(t_cmd, "list_insert_ordered")){
            struct list_item *new_item=(struct list_item*)malloc(sizeof(struct list_item));
            
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            void *aux;

            new_item = list_entry(&(new_item->elem),struct list_item, elem);
            new_item->data = atoi(cmd2);
            list_insert_ordered(L[index_l].link, &(new_item->elem), list_less, aux);
        }
        else if (!strcmp(t_cmd, "list_push_front")){
            struct list_item *new_item=(struct list_item*)malloc(sizeof(struct list_item));
            
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);

            list_push_front(L[index_l].link,&(new_item->elem));
            new_item = list_entry(&(new_item->elem),struct list_item,elem);
            new_item->data = atoi(cmd2);
        }
        else if (!strcmp(t_cmd, "list_push_back")){
            struct list_item *new_item=(struct list_item*)malloc(sizeof(struct list_item));
            
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);

            list_push_back(L[index_l].link,&(new_item->elem));
            new_item = list_entry(&(new_item->elem),struct list_item,elem);
            new_item->data = atoi(cmd2);
        }
        else if (!strcmp(t_cmd, "list_front")){
            struct list_elem *e;
            struct list_item *temp=(struct list_item*)malloc(sizeof(struct list_item));
            
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            e = list_front(L[index_l].link);
            temp = list_entry(e, struct list_item, elem);
            printf("%d\n",temp->data);
        }
        else if (!strcmp(t_cmd, "list_front")){
            struct list_elem *e;
            struct list_item *temp=(struct list_item*)malloc(sizeof(struct list_item));
            
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            e = list_front(L[index_l].link);
            temp = list_entry(e, struct list_item, elem);
            printf("%d\n",temp->data);
        }
        else if (!strcmp(t_cmd, "list_pop_front")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            list_pop_front(L[index_l].link);
        }
        else if (!strcmp(t_cmd, "list_back")){
            struct list_elem *e;
            struct list_item *temp=(struct list_item*)malloc(sizeof(struct list_item));

            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            e = list_back(L[index_l].link);
            temp = list_entry(e, struct list_item, elem);
            printf("%d\n",temp->data);
        }
        else if (!strcmp(t_cmd, "list_pop_back")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            list_pop_back(L[index_l].link);
        }
        else if (!strcmp(t_cmd, "list_empty")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);

            if (list_empty(L[index_l].link))
                printf("true\n");
            else
                printf("false\n");
        }
        else if (!strcmp(t_cmd, "list_size")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            printf("%zu\n",list_size(L[index_l].link));
        }
        else if (!strcmp(t_cmd, "list_max")){
            struct list_elem *e;
            struct list_item *temp=(struct list_item*)malloc(sizeof(struct list_item));
            void *aux;
            
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            e = list_max(L[index_l].link, list_less, aux);
            temp = list_entry(e,struct list_item, elem);
            printf("%d\n",temp->data);
        }
        else if (!strcmp(t_cmd, "list_min")){
            struct list_elem *e;
            struct list_item *temp=(struct list_item*)malloc(sizeof(struct list_item));
            
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            void *aux;

            e = list_min(L[index_l].link, list_less, aux);
            temp = list_entry(e,struct list_item, elem);
            printf("%d\n",temp->data);
        }
        else if (!strcmp(t_cmd, "list_remove")){
            struct list_elem *e;

            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);

            e = list_begin(L[index_l].link);
            for (int i=0;i<atoi(cmd2);i++)
                e = list_next(e);
            list_remove(e);
        }
        else if (!strcmp(t_cmd, "list_reverse")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            list_reverse(L[index_l].link);
        }
        else if (!strcmp(t_cmd, "list_sort")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            list_sort(L[index_l].link,list_less, NULL);
        }
        else if (!strcmp(t_cmd, "list_splice")){
            struct list_elem *before, *first, *last;
            int index_l_2;
            
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            strcpy(cmd4, strtok(NULL," "));
            strcpy(cmd5, strtok(NULL," "));

            index_l = search_l_idx(cnt_l,cmd1);
            index_l_2 = search_l_idx(cnt_l,cmd3);

            first = list_begin(L[index_l_2].link);
            for (int i=0;i<atoi(cmd4);i++)
                first = list_next(first);
            last = list_begin(L[index_l_2].link);
            for (int i=0;i<atoi(cmd5);i++)
                last = list_next(last);
            before = list_begin(L[index_l].link);
            for (int i=0;i<atoi(cmd2);i++)
                before = list_next(before);
            list_splice(before,first,last);
        }
        else if (!strcmp(t_cmd, "list_unique")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            char *find = strtok(NULL, " ");
            void *aux;

            if (find != NULL){
                strcpy(cmd2,find);
                int index_l_2 =  search_l_idx(cnt_l,cmd2);
                list_unique(L[index_l].link,L[index_l_2].link,list_less,aux);
            }
            else{
                list_unique(L[index_l].link,NULL,list_less,aux);
            }
        }
        else if (!strcmp(t_cmd, "list_swap")){
            struct list_elem *ai, *bi;

            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            
            ai = list_begin(L[index_l].link);
            for (int i=0;i<atoi(cmd2);i++)
                ai = list_next(ai);
            bi = list_begin(L[index_l].link);
            for (int i=0;i<atoi(cmd3);i++)
                bi = list_next(bi);
            list_swap(ai,bi);
        }
        else if (!strcmp(t_cmd, "list_shuffle")){
            strcpy(cmd1, strtok(NULL," "));
            index_l = search_l_idx(cnt_l,cmd1);
            list_shuffle(L[index_l].link);
        }

        //hash 명령어
        else if (!strcmp(t_cmd, "hash_insert")){
            struct hash_elem *el = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct hash_item *ite = (struct hash_item*)malloc(sizeof(struct hash_item));
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2,strtok(NULL," "));

            index_h = search_h_idx(cnt_h,cmd1);
            ite = hash_entry(el,struct hash_item, elem);
            ite->data = atoi(cmd2);
            hash_insert(H[index_h].link,el);
        }
        else if (!strcmp(t_cmd, "hash_replace")){
            struct hash_elem *el = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct hash_item *ite = (struct hash_item*)malloc(sizeof(struct hash_item));
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2,strtok(NULL," "));

            index_h = search_h_idx(cnt_h,cmd1);
            ite = hash_entry(el,struct hash_item, elem);
            ite->data = atoi(cmd2);
            hash_replace(H[index_h].link,el);
        }
        else if (!strcmp(t_cmd, "hash_find")){
            struct hash_elem *el = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct hash_item *ite = (struct hash_item*)malloc(sizeof(struct hash_item));
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2,strtok(NULL," "));

            index_h = search_h_idx(cnt_h,cmd1);
            ite = hash_entry(el,struct hash_item, elem);
            ite->data = atoi(cmd2);
            el = hash_find(H[index_h].link,&(ite->elem));

            if (el != NULL){
                ite = hash_entry(el, struct hash_item, elem);
                printf("%d\n",ite->data);
            } 
        }
        else if (!strcmp(t_cmd, "hash_delete")){
            struct hash_elem *el = (struct hash_elem*)malloc(sizeof(struct hash_elem));
			struct hash_item *ite = (struct hash_item*)malloc(sizeof(struct hash_item));
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2,strtok(NULL," "));

            index_h = search_h_idx(cnt_h,cmd1);
            ite->data = atoi(cmd2);
            el = hash_delete(H[index_h].link,&(ite->elem));
        }
        else if (!strcmp(t_cmd, "hash_apply")){
            struct hash_elem *el = (struct hash_elem*)malloc(sizeof(struct hash_elem));
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2,strtok(NULL," "));
            index_h = search_h_idx(cnt_h,cmd1);

            if (!strcmp(cmd2,"square"))
                hash_apply(H[index_h].link,hash_action_square);
            else if (!strcmp(cmd2,"triple"))
                hash_apply(H[index_h].link,hash_action_triple);
        }
        else if (!strcmp(t_cmd, "hash_size")){
            strcpy(cmd1, strtok(NULL," "));
            index_h = search_h_idx(cnt_h,cmd1);
            printf("%zu\n",hash_size(H[index_h].link));
        }
        else if (!strcmp(t_cmd, "hash_empty")){
            strcpy(cmd1, strtok(NULL," "));
            index_h = search_h_idx(cnt_h,cmd1);
            if (hash_empty(H[index_h].link))
                printf("true\n");
            else
                printf("false\n");
        }
        else if (!strcmp(t_cmd, "hash_clear")){
            strcpy(cmd1, strtok(NULL," "));
            index_h = search_h_idx(cnt_h,cmd1);
            hash_clear(H[index_h].link,hash_action_destructor);
        }

        ///bitmap 명령어
        else if (!strcmp(t_cmd, "bitmap_all")){
            size_t s,n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            s = atoi(cmd2);
            n = atoi(cmd3);

            index_b = search_b_idx(cnt_b,cmd1);
            if (bitmap_all(B[index_b].link,s,n))
                printf("true\n");
            else
                printf("false\n");
        }
        else if (!strcmp(t_cmd, "bitmap_any")){
            size_t s,n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            s = atoi(cmd2);
            n = atoi(cmd3);

            index_b = search_b_idx(cnt_b,cmd1);
            if (bitmap_any(B[index_b].link,s,n))
                printf("true\n");
            else
                printf("false\n");
        }
        else if (!strcmp(t_cmd, "bitmap_none")){
            size_t s,n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            s = atoi(cmd2);
            n = atoi(cmd3);

            index_b = search_b_idx(cnt_b,cmd1);
            if (bitmap_none(B[index_b].link,s,n))
                printf("true\n");
            else
                printf("false\n");
        }
        else if (!strcmp(t_cmd, "bitmap_contains")){
            size_t s,n;
            bool v=0;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            strcpy(cmd4, strtok(NULL," "));
            s = atoi(cmd2);
            n = atoi(cmd3);

            if (!strcmp(cmd4,"true"))
                v = 1;
            index_b = search_b_idx(cnt_b,cmd1);
            if (bitmap_contains(B[index_b].link,s,n,v))
                printf("true\n");
            else
                printf("false\n");
        }
        else if (!strcmp(t_cmd, "bitmap_count")){
            size_t s,n;
            bool v=0;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            strcpy(cmd4, strtok(NULL," "));
            s = atoi(cmd2);
            n = atoi(cmd3);

            if (!strcmp(cmd4,"true"))
                v = 1;
            index_b = search_b_idx(cnt_b,cmd1);
            printf("%zu\n",bitmap_count(B[index_b].link,s,n,v));
        }
        else if (!strcmp(t_cmd, "bitmap_mark")){
            size_t n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            n = atoi(cmd2);

            index_b = search_b_idx(cnt_b,cmd1);
            bitmap_mark(B[index_b].link,n);
        }
        else if (!strcmp(t_cmd, "bitmap_flip")){
            size_t n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            n = atoi(cmd2);

            index_b = search_b_idx(cnt_b,cmd1);
            bitmap_flip(B[index_b].link,n);
        }
        else if (!strcmp(t_cmd, "bitmap_scan")){
            size_t n1,n2;
            bool v=0;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            strcpy(cmd4, strtok(NULL," "));
            n1 = atoi(cmd2);
            n2 = atoi(cmd3);

            if (!strcmp(cmd4,"true"))
                v = 1;
            index_b = search_b_idx(cnt_b,cmd1);
            printf("%zu\n",bitmap_scan(B[index_b].link,n1,n2,v));
        }
        else if (!strcmp(t_cmd, "bitmap_scan_and_flip")){
            size_t n1,n2;
            bool v = 0;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            strcpy(cmd4, strtok(NULL," "));
            n1 = atoi(cmd2);
            n2 = atoi(cmd3);

            if (!strcmp(cmd4,"true"))
                v = 1;
            index_b = search_b_idx(cnt_b,cmd1);
            printf("%zu\n",bitmap_scan_and_flip(B[index_b].link,n1,n2,v));
        }
        else if (!strcmp(t_cmd, "bitmap_reset")){
            size_t n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            n = atoi(cmd2);

            index_b = search_b_idx(cnt_b,cmd1);
            bitmap_reset(B[index_b].link,n);
        }
        else if (!strcmp(t_cmd, "bitmap_set")){
            size_t n;
            bool v=0;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            n = atoi(cmd2);

            if (!strcmp(cmd3,"true"))
                v = 1; 
            index_b = search_b_idx(cnt_b,cmd1);
            bitmap_set(B[index_b].link,n,v);
        }
        else if (!strcmp(t_cmd, "bitmap_set_all")){
            bool v=0;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));

            if (!strcmp(cmd2,"true"))
                v = 1;
            index_b = search_b_idx(cnt_b,cmd1);
            bitmap_set_all(B[index_b].link,v);
        }
        else if (!strcmp(t_cmd, "bitmap_set_multiple")){
            size_t n1,n2;
            bool v=0;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            strcpy(cmd3, strtok(NULL," "));
            strcpy(cmd4, strtok(NULL," "));
            n1 = atoi(cmd2);
            n2 = atoi(cmd3);

            if (!strcmp(cmd4,"true"))
                v = 1;
            index_b = search_b_idx(cnt_b,cmd1);
            bitmap_set_multiple(B[index_b].link,n1,n2,v);
        }
        else if (!strcmp(t_cmd, "bitmap_size")){
            strcpy(cmd1, strtok(NULL," "));

            index_b = search_b_idx(cnt_b,cmd1);
            printf("%zu\n",bitmap_size(B[index_b].link));
        }
        else if (!strcmp(t_cmd, "bitmap_expand")){
            int n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            n = atoi(cmd2);

            index_b = search_b_idx(cnt_b,cmd1);
            B[index_b].link = bitmap_expand(B[index_b].link,n);
        }
        else if (!strcmp(t_cmd, "bitmap_dump")){
            strcpy(cmd1, strtok(NULL," "));

            index_b = search_b_idx(cnt_b,cmd1);
            bitmap_dump(B[index_b].link);
        }
        else if (!strcmp(t_cmd, "bitmap_test")){
            size_t n;
            strcpy(cmd1, strtok(NULL," "));
            strcpy(cmd2, strtok(NULL," "));
            n = atoi(cmd2);

            index_b = search_b_idx(cnt_b,cmd1);
            if(bitmap_test(B[index_b].link,n))
                printf("true\n");
            else
                printf("false\n");
        }
    }

    return 0;
}