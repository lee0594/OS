#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "userprog/process.h"
#include "devices/shutdown.h"
#define STDIN 0
#define STDOUT 1

typedef int pid_t;

static void syscall_handler (struct intr_frame *);
static void accessing_memory_check(void *esp, struct thread *t, int cn);
void halt(void);
void exit(int status);
int wait (pid_t pid);
pid_t exec(const char *file);
int read (int fd, void *buffer, unsigned length);
int write (int fd, const void *buffer, unsigned length);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

///user memory access check
static void accessing_memory_check(void *esp, struct thread *t, int cn){
  for (int i=0;i<=cn;i++){
    if (!is_user_vaddr(esp))
      exit(-1);
    if (pagedir_get_page(t->pagedir, esp) == NULL)
      exit(-1);
  }
}

static void
syscall_handler (struct intr_frame *f) 
{
  struct thread *t = thread_current();
  accessing_memory_check(f->esp,t,0);

  int syscall_num = *(int *)(f->esp);
  switch(syscall_num){
    case SYS_HALT:
      halt();
      break;
    case SYS_EXIT:
      accessing_memory_check(f->esp, t, 1);
      exit(*(int*)(f->esp+4));
      break;
    case SYS_EXEC:
      accessing_memory_check(f->esp, t, 1);
      f->eax = exec(*(char**)(f->esp+4));
      break;
    case SYS_WAIT:
      accessing_memory_check(f->esp, t, 1);
      f->eax = wait(*(pid_t*)(f->esp+4));
      break;
    case SYS_READ:
      accessing_memory_check(f->esp, t, 3);
      read(*(int*)(f->esp+4), *(void**)(f->esp+8), *(unsigned*)(f->esp+12));
      break;
    case SYS_WRITE:
      accessing_memory_check(f->esp, t, 3);
      write(*(int*)(f->esp+4), *(void**)(f->esp+8), *(unsigned*)(f->esp+12));
      break;
    case SYS_FIBONACCI:
      accessing_memory_check(f->esp, t, 1);
      f->eax = fibonacci(*(int*)(f->esp+4));
      break;
    case SYS_MAX_OF_FOUR_INT:
      accessing_memory_check(f->esp, t, 4);
      f->eax = max_of_four_int(*(int*)(f->esp+4), *(int*)(f->esp+8), *(int*)(f->esp+16), *(int*)(f->esp+20));
      break;
    default:
      thread_exit ();
  }
}

void halt(void){
  shutdown_power_off();
}

void exit(int status){
  struct thread *t = thread_current();
  t->exit_status = status;
  printf("%s: exit(%d)\n",t->name,status);

  thread_exit();
}

int wait (pid_t pid){
  return process_wait((tid_t)pid);
}

pid_t exec(const char *file){
  return process_execute(file);
}

int read (int fd, void *buffer, unsigned length){
  unsigned i;
  if (fd==STDIN){
    for (i=0;i<length;i++){
      *(uint8_t*)buffer = input_getc();
      buffer+=sizeof(uint8_t);
    }
  }
  else
    exit(-1);

  return length;
}

int write (int fd, const void *buffer, unsigned length){
  if (fd == STDOUT){
    putbuf(buffer,length);
  }
  else
    exit(-1);
  
  return length;
}

int fibonacci(int n){
  int fibo_f=0, fibo_s=1, fibo_r;

  if (n<=0)
    exit(-1);
  
  for (int i=1;i<n;i++){
    fibo_r = fibo_f+fibo_s;
    fibo_f = fibo_s;
    fibo_s = fibo_r;
  }
  
  return fibo_s;
}

int max_of_four_int(int a, int b, int c, int d){
  int max_t1, max_t2, max;
  max_t1 = a > b ? a : b;
  max_t2 = c > d ? c : d;
  max = max_t1 > max_t2 ? max_t1 : max_t2;

  return max;
}
