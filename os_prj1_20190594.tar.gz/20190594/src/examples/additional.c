/// additional syscall examples
#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>

int main(int argc, char *argv[]){
    if (argc != 5){
        printf("We need 5 argv: additional num1 num2 num3 num4\n");
        return EXIT_FAILURE;
    }

    int fibo = fibonacci(atoi(argv[1]);
    int max_four = max_of_four_int(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
    printf("%d %d\n", fibo, max_four);

    return EXIT_SUCCESS;
}
