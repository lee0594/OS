#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "devices/input.h"
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "userprog/process.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "devices/input.h"
#include "threads/synch.h"
#include "filesys/off_t.h"
#include <string.h>
#include <stdbool.h>
#define STDIN 0
#define STDOUT 1
#define STDERR 2

struct lock file_lock; ////read(), write() 시스템 콜에서 파일 접근하기 전에 lock을 획득하도록 구현, file에 대한 접근이 끝난 뒤 lock 해제

typedef int pid_t;

struct file
{
  struct inode *inode;        /* File's inode. */
  off_t pos;                  /* Current position. */
  bool deny_write;            /* Has file_deny_write() been called? */
};

static void syscall_handler (struct intr_frame *);
static void accessing_memory_check(void *esp, struct thread *t, int cn);
void halt(void);
void exit(int status);
int wait (pid_t pid);
pid_t exec(const char *file);
int read (int fd, void *buffer, unsigned length);
int write (int fd, const void *buffer, unsigned length);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);

////
bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
int filesize (int fd);
void seek (int fd, unsigned position); 
unsigned tell (int fd);
void close (int fd);

void
syscall_init (void) 
{
  lock_init(&file_lock); /////read(), write() 시스템 콜에서 파일 접근하기 전에 lock을 획득하도록 구현, file에 대한 접근이 끝난 뒤 lock 해제
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

///user memory access check
static void accessing_memory_check(void *esp, struct thread *t, int cn){
  for (int i=0;i<=cn;i++){
    if (!is_user_vaddr((void*)(esp+4*i))){
      exit(-1);
    }
    if (pagedir_get_page(t->pagedir, (void*)(esp+4*i)) == NULL){
      exit(-1);
    }
  }
}

static void
syscall_handler (struct intr_frame *f) 
{
  struct thread *t = thread_current();
  accessing_memory_check(f->esp,t,0);

  int syscall_num = *(uint32_t*)(f->esp);
  switch(syscall_num){
    case SYS_HALT:
      halt();
      break;
    case SYS_EXIT:
      accessing_memory_check(f->esp, t, 1);
      exit(*(int*)(f->esp+4));
      break;
    case SYS_EXEC:
      accessing_memory_check(f->esp, t, 1);
      f->eax = exec(*(char**)(f->esp+4));
      break;
    case SYS_WAIT:
      accessing_memory_check(f->esp, t, 1);
      f->eax = wait(*(pid_t*)(f->esp+4));
      break;
    case SYS_CREATE:
      accessing_memory_check(f->esp, t, 2);
      f->eax = create(*(char**)(f->esp+4), *(unsigned*)(f->esp+8));
      break;
    case SYS_REMOVE:
      accessing_memory_check(f->esp, t, 1);
      f->eax = remove(*(char**)(f->esp+4));
      break;
    case SYS_OPEN:
      accessing_memory_check(f->esp, t, 1);
      f->eax = open(*(char**)(f->esp+4));
      break;
    case SYS_FILESIZE:
      accessing_memory_check(f->esp, t, 1);
      f->eax = filesize(*(int*)(f->esp+4));
		  break;
    case SYS_READ:
      accessing_memory_check(f->esp, t, 3);
      f->eax = read((int)*(uint32_t *)(f->esp+4), *(void**)(f->esp+8), *(unsigned*)(f->esp+12));
      break;
    case SYS_WRITE:
      accessing_memory_check(f->esp, t, 3);
      f->eax = write(*(int*)(f->esp+4), (void *)*(uint32_t *)(f->esp+8), *(unsigned*)(f->esp+12));
      break;
    case SYS_SEEK:
      accessing_memory_check(f->esp, t, 2);
      seek(*(int*)(f->esp+4), *(unsigned*)(f->esp+8));
		  break;
    case SYS_TELL:
      accessing_memory_check(f->esp, t, 1);
      f->eax = tell(*(int*)(f->esp+4));
		  break;
    case SYS_CLOSE:
      accessing_memory_check(f->esp, t, 1);
      close(*(int*)(f->esp+4));
		  break;
    case SYS_FIBONACCI:
      accessing_memory_check(f->esp, t, 1);
      f->eax = fibonacci(*(int*)(f->esp+4));
      break;
    case SYS_MAX_OF_FOUR_INT:
      accessing_memory_check(f->esp, t, 4);
      f->eax = max_of_four_int(*(int*)(f->esp+4), *(int*)(f->esp+8), *(int*)(f->esp+16), *(int*)(f->esp+20));
      break;
    default:
      exit(-1);
  }
}

void halt(void){
  shutdown_power_off();
}

void exit(int status){
  struct thread *t = thread_current();
  printf("%s: exit(%d)\n",t->name,status);
  t->exit_status = status;

  ////
  for (int i=3;i<128;i++){
    if (t->fd[i]!=NULL){
      close(i);
    }
  }
  thread_exit();
}

int wait (pid_t pid){
  return process_wait((tid_t)pid);
}

pid_t exec(const char *file){
  return process_execute(file);
}

int read (int fd, void *buffer, unsigned length)
{
    unsigned int i;
    int value = 0;
    struct thread *t = thread_current();

    lock_acquire(&file_lock);

    if(fd == STDIN){
      for (i = 0; i < length; i++){
        if (((char *)buffer)[i] == '\0'){
          break;
        }
      }
      //value = length;
      value = i;
    }
    else if(fd >= 3){
        if(thread_current()->fd[fd] == NULL){
          lock_release(&file_lock); 
          exit(-1);
        }
        value = file_read(t->fd[fd], buffer, length);
    }
    else {
      lock_release(&file_lock); 
      exit(-1);
    }
    lock_release(&file_lock);
    return value;
}

int write (int fd, const void *buffer, unsigned length)
{
  int value = -1;
  struct thread *t = thread_current();

  lock_acquire(&file_lock);
  if (fd == STDOUT){
      putbuf(buffer, length);
      value = length;
  }
  else if(fd >= 3){
    if (t->fd[fd] == NULL){ 
      lock_release(&file_lock); 
      exit(-1);
    }
    if (t->fd[fd]->deny_write){
      file_deny_write(t->fd[fd]);
    }
    value = file_write(t->fd[fd], buffer, length);
  }
  else{
    lock_release(&file_lock); 
    exit(-1);
  }
  lock_release(&file_lock);

  return value;
}

int fibonacci(int n){
  int fibo_f=0, fibo_s=1, fibo_r;

  if (n<=0){
    exit(-1);
  }
  
  for (int i=1;i<n;i++){
    fibo_r = fibo_f+fibo_s;
    fibo_f = fibo_s;
    fibo_s = fibo_r;
  }
  
  return fibo_s;
}

int max_of_four_int(int a, int b, int c, int d){
  int max_t1, max_t2, max;
  max_t1 = a > b ? a : b;
  max_t2 = c > d ? c : d;
  max = max_t1 > max_t2 ? max_t1 : max_t2;

  return max;
}

bool create (const char *file, unsigned initial_size)
{
  if (file == NULL){
    exit(-1);
  }
  
  return filesys_create(file, initial_size);
}

bool remove (const char *file)
{
  if (file == NULL){
    exit(-1);
  }
  
  return filesys_remove(file);
}

int open (const char *file)
{
  struct thread *t = thread_current();
  int fd = -1;

  if (file == NULL){
    exit(-1);
  }

  lock_acquire(&file_lock);
  struct file *fp = filesys_open(file);
  if (fp == NULL){
    fd = -1;
  }
  else{
    for(int i=3;i<128;i++){
      if(t->fd[i] == NULL){
        if(!strcmp(t->name, file)){
          file_deny_write(fp);
        }
        t->fd[i] = fp;
        fd = i;
        break;
      }
    }
  }	
  lock_release(&file_lock);

  return fd;
}

int filesize (int fd)
{
  struct thread *t = thread_current();
  if (t->fd[fd] == NULL){
    exit(-1);
  }

  return (int)file_length(t->fd[fd]);
}

void seek (int fd, unsigned position)
{
  struct thread *t = thread_current();
  if (t->fd[fd] == NULL){
    exit(-1);
  }

  return file_seek(t->fd[fd], position);
}

unsigned tell (int fd)
{
  struct thread *t = thread_current();
  if (t->fd[fd] == NULL){
    exit(-1);
  }

  return file_tell(t->fd[fd]);
}

void close (int fd)
{
  struct thread *t = thread_current();
  if(t->fd[fd] == NULL){
    exit(-1);
  }
  t->fd[fd] = NULL;
  file_close(t->fd[fd]);
}
